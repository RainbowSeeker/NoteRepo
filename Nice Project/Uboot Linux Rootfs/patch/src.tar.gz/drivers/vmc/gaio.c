#include <linux/init.h>
#include <linux/module.h>
#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/io.h>
#include <linux/delay.h>
#define DEV_NAME            "gaio"
#define DEV_CNT           	(1)

// #define DRV_DBG(...)		pr_info(__VA_ARGS__)

#ifndef DRV_DBG
#define DRV_DBG(...)
#endif // DRV_DBG

#define PGAO	dev->va_gao
#define PGAI	dev->va_gai

typedef struct {
	uint32_t  enable;
	uint32_t  config;
	uint32_t  reset;
	uint32_t  out[4];
} GAO_REG, *PGAO_REG;


typedef struct {
	uint32_t  in[12];
} GAI_REG, *PGAI_REG;

struct gaio_chrdev {
    struct cdev dev;
    GAO_REG __iomem *va_gao;     
    GAI_REG __iomem *va_gai;        
};

static dev_t devid;
static struct class *gaio_class;

static int gaio_open(struct inode *inode, struct file *filp)
{
    struct gaio_chrdev *dev =
        (struct gaio_chrdev *)container_of(inode->i_cdev, struct gaio_chrdev,
                          dev);
    filp->private_data = dev;

    DRV_DBG("[gaio]: open\n");

    dev->va_gao = ioremap(0xC20C3000, sizeof(GAO_REG));
    dev->va_gai = ioremap(0xC20C30C0, sizeof(GAI_REG));


	PGAO->enable = 0;
	PGAO->config = 0xf | 0x40;	//+-10V
	
	PGAO->enable = 1;
	PGAO->reset = 1;

    return 0;
}

static int gaio_release(struct inode *inode, struct file *filp)
{
    struct gaio_chrdev *dev =
        (struct gaio_chrdev *)container_of(inode->i_cdev, struct gaio_chrdev,
                          dev);

	PGAO->enable = 0;

    iounmap(dev->va_gao);        
    iounmap(dev->va_gai); 

    DRV_DBG("[gaio]: release\n");
    return 0;
}

#define noneg(_x)	((_x) > 0 ? (_x) : 0) 

static ssize_t gaio_read(struct file *filp, char __user * buf,
                size_t count, loff_t * ppos)
{
    struct gaio_chrdev *dev = (struct gaio_chrdev *)filp->private_data;

	uint16_t val = PGAI->in[*ppos] & 0xFFFF;
	put_user(val, (uint16_t __user *)buf);
	
    return 1;
}

static ssize_t gaio_write(struct file *filp, const char __user * buf,
                size_t count, loff_t * ppos)
{
    struct gaio_chrdev *dev = (struct gaio_chrdev *)filp->private_data;

	uint16_t val;
    get_user(val, (uint16_t __user *)buf);
	PGAO->out[*ppos] = val;

	return 1;
}


static struct file_operations gaio_fops = {
    .owner = THIS_MODULE,
    .open = gaio_open,
    .release = gaio_release,
    .read = gaio_read,
    .write = gaio_write,
    .llseek = noop_llseek
};

static struct gaio_chrdev gaio_cdev[DEV_CNT];

static __init int gaio_init(void)
{
    dev_t cur_dev;
    int i;

    DRV_DBG("[gaio]: chrdev init \n");


    alloc_chrdev_region(&devid, 0, DEV_CNT, DEV_NAME);

    gaio_class = class_create(THIS_MODULE, DEV_NAME);

    for (i = 0; i < DEV_CNT; i++) {
        cdev_init(&gaio_cdev[i].dev, &gaio_fops);
        gaio_cdev[i].dev.owner = THIS_MODULE;

        cur_dev = MKDEV(MAJOR(devid), MINOR(devid) + i);

        cdev_add(&gaio_cdev[i].dev, cur_dev, 1);

        device_create(gaio_class, NULL, cur_dev, NULL,
                  DEV_NAME "%d", i);
    }

    return 0;
}

static __exit void gaio_exit(void)
{
    int i;
    dev_t cur_dev;
    DRV_DBG("[gaio]: chrdrv exit\n");
    
    for (i = 0; i < DEV_CNT; i++) {
        cur_dev = MKDEV(MAJOR(devid), MINOR(devid) + i);

        device_destroy(gaio_class, cur_dev);

        cdev_del(&gaio_cdev[i].dev);
    }
    unregister_chrdev_region(devid, DEV_CNT);
    class_destroy(gaio_class);
}

module_init(gaio_init);
module_exit(gaio_exit);


MODULE_LICENSE("GPL");
MODULE_AUTHOR("RainbowSeeker");
MODULE_DESCRIPTION("Driver for gaio of fpga");
