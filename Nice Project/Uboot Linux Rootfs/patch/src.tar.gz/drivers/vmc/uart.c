#include <linux/init.h>
#include <linux/module.h>
#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/io.h>

#define DEV_NAME            "uart"
#define DEV_CNT           	(4)

// #define DRV_DBG(...)		pr_info(__VA_ARGS__)
#define DRV_DBG(...)		

#define SET_VAL(_reg, _val) (_reg) = (_val)
#define GET_VAL(_reg)       (_reg)

static dev_t devid;
static struct class *uart_class;

#define	BASE_RCS3		    (0xC2000000)
#define PUART_TX_ADDR(_port)		(BASE_RCS3 + 0xC0400 + 0x800 * (_port))
#define PUART_RX_ADDR(_port)		(BASE_RCS3 + 0xC0000 + 0x800 * (_port))

#define BUADRATE            115200

typedef struct {
	unsigned int baud;
	unsigned int config;
	unsigned int fifo_clr;
	unsigned int data;
	unsigned int fifo_len;
} UART_F_REG, *PUART_F_REG;

typedef struct {
	unsigned int baud_lock;		// 0x0
	unsigned int stat_unlock;		// 0x4
	unsigned int clr_of;			// 0x8
	unsigned int baud;				// 0xC
	unsigned int parity;			// 0x10
	unsigned int frame_len;		// 0x14
	unsigned int head1;			// 0x18
	unsigned int head2;			// 0x1C
	unsigned int head3;			// 0x20
	unsigned int head4;			// 0x24
	unsigned int head_len;			// 0x28
	unsigned int version;			// 0x2C
	unsigned int pkg_gap;			// 0x30
	unsigned int enable;			// 0x34
} UART_DP_REG, *PUART_DP_REG;

struct uart_chrdev {
    struct cdev dev;
    UART_F_REG __iomem *va_uart_tx;       
    UART_DP_REG __iomem *va_uart_dp;
    uint8_t     portid;    
};

#define puart_tx        dev->va_uart_tx
#define puart_dp        dev->va_uart_dp

static int uart_open(struct inode *inode, struct file *filp)
{
    struct uart_chrdev *dev =
        (struct uart_chrdev *)container_of(inode->i_cdev, struct uart_chrdev,
                          dev);
    filp->private_data = dev;

    DRV_DBG("[uart]: open\n");

    dev->va_uart_tx = ioremap(PUART_TX_ADDR(dev->portid), sizeof(UART_F_REG));
    dev->va_uart_dp = ioremap(PUART_RX_ADDR(dev->portid), max(sizeof(UART_DP_REG), 128));

    //tx config
    puart_tx->baud = BUADRATE/100;
    puart_tx->config = (0 << 4) | 1;

    //rx config
    puart_dp->baud = BUADRATE/100;
    puart_dp->parity = 0 | (1 << 1);
    puart_dp->pkg_gap = 0xff;

    puart_dp->enable = 1;
    puart_dp->clr_of = 1;
    puart_dp->frame_len = 128;

    return 0;
}

static int uart_release(struct inode *inode, struct file *filp)
{
    struct uart_chrdev *dev =
        (struct uart_chrdev *)container_of(inode->i_cdev, struct uart_chrdev,
                          dev);
    iounmap(dev->va_uart_tx);        
    iounmap(dev->va_uart_dp); 
    DRV_DBG("[uart]: release\n");
    return 0;
}

static ssize_t uart_read(struct file *filp, char __user * buf,
                size_t count, loff_t * ppos)
{
    struct uart_chrdev *dev = (struct uart_chrdev *)filp->private_data;
    size_t i;

    DRV_DBG("[uart]: read %d\n", count);

	if(puart_dp->stat_unlock & 0x100)
	{
        puart_dp->baud_lock = 1;
		
        count = min(count, 128);
        for (i = 0; i < count; i++)
        {
            uint8_t val = (unsigned char)(*((unsigned int *)puart_dp + i));
            put_user(val, buf + i);
        }

        puart_dp->stat_unlock = 1;

		return count;
	}

    return 0;
}

static ssize_t uart_write(struct file *filp, const char __user * buf,
                size_t count, loff_t * ppos)
{
    struct uart_chrdev *dev = (struct uart_chrdev *)filp->private_data;
    char ch;

    DRV_DBG("[uart]: write %d\n", count);

    size_t i;
	for (i = 0; i < count; i++)
	{
        get_user(ch, buf + i);
	    while((puart_tx->config >> 12) & 1) {};
        puart_tx->data = ch;
	}
	return count;
}

#define UART_SET_BAUDRATE	_IOW('m', 0x01, u32) 
#define UART_GET_BAUDRATE	_IOW('m', 0x02, u32) 
#define UART_SET_FRAMELEN	_IOW('m', 0x03, u32) 
#define UART_GET_FRAMELEN	_IOW('m', 0x04, u32) 

static long uart_ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
{
	struct uart_chrdev *dev = (struct uart_chrdev *)filp->private_data;
	void __user *argp = (void __user *)arg;
	switch (cmd)
	{
	case UART_SET_BAUDRATE:
    {
        u32 baud;
        if (copy_from_user(&baud, argp, 4))
			return -EFAULT;
		puart_tx->baud = baud/100;
        puart_dp->baud = baud/100;
		DRV_DBG("[uart] baud set to %d.\n", baud);
		break;
    }
	case UART_GET_BAUDRATE:
    {
        u32 baud = puart_tx->baud;
		if (copy_to_user(argp, &baud, 4))
			return -EFAULT;
		DRV_DBG("[uart] baud:%d.\n", baud);
		break;
    }
	case UART_SET_FRAMELEN:
    {
        u32 frame_len;
		if (copy_from_user(&frame_len, argp, 4))
			return -EFAULT;

        puart_dp->frame_len = frame_len;
		DRV_DBG("[uart] frame_len set to %d.\n", frame_len);
		break;
    }
	case UART_GET_FRAMELEN:
    {
        u32 frame_len = puart_dp->frame_len;
		if (copy_to_user(argp, &frame_len, 4))
			return -EFAULT;
		DRV_DBG("[uart] frame_len %d.\n", frame_len);
		break;
    }
	default:
		break;
	}
	
	return 0;
}
static struct file_operations uart_fops = {
    .owner = THIS_MODULE,
    .open = uart_open,
    .release = uart_release,
    .read = uart_read,
    .write = uart_write,
    .unlocked_ioctl = uart_ioctl,
};

static struct uart_chrdev uart_cdev[DEV_CNT];

static __init int uart_init(void)
{
    dev_t cur_dev;

    DRV_DBG("[uart]: chrdev init \n");


    alloc_chrdev_region(&devid, 0, DEV_CNT, DEV_NAME);

    uart_class = class_create(THIS_MODULE, DEV_NAME);

    int i;
    for (i = 0; i < DEV_CNT; i++) {
        cdev_init(&uart_cdev[i].dev, &uart_fops);
        uart_cdev[i].dev.owner = THIS_MODULE;
        uart_cdev[i].portid = i;

        cur_dev = MKDEV(MAJOR(devid), MINOR(devid) + i);

        cdev_add(&uart_cdev[i].dev, cur_dev, 1);

        device_create(uart_class, NULL, cur_dev, NULL,
                  DEV_NAME "%d", i);
    }

    return 0;
}

static __exit void uart_exit(void)
{
    int i;
    dev_t cur_dev;
    DRV_DBG("[uart]: chrdrv exit\n");
    
    for (i = 0; i < DEV_CNT; i++) {
        cur_dev = MKDEV(MAJOR(devid), MINOR(devid) + i);

        device_destroy(uart_class, cur_dev);

        cdev_del(&uart_cdev[i].dev);
    }
    unregister_chrdev_region(devid, DEV_CNT);
    class_destroy(uart_class);
}

module_init(uart_init);
module_exit(uart_exit);


MODULE_LICENSE("GPL");
MODULE_AUTHOR("RainbowSeeker");
MODULE_DESCRIPTION("Driver for uart of fpga");
