#include <linux/init.h>
#include <linux/module.h>
#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/io.h>
#include <linux/delay.h>
#define DEV_NAME            "gdio"
#define DEV_CNT           	(1)

// #define DRV_DBG(...)		pr_info(__VA_ARGS__)

#ifndef DRV_DBG
#define DRV_DBG(...)
#endif // DRV_DBG

#define limit(_lower, _x, _higher)  (_x) > (_lower) ? ((_x) < (_higher) ? (_x) : (_higher)) : (_lower)

#define PGDIO	dev->va_gdio

typedef struct {
	uint32_t  sync_dpv_chv_o;
	uint32_t  do_bus;
	uint32_t  resverse[2];
	uint32_t  sync_dpv_chv_i;
	uint32_t  di_bus;
} GDIO_REG, *PGDIO_REG;

struct gdio_chrdev {
    struct cdev dev;
    GDIO_REG __iomem *va_gdio;        
};

static dev_t devid;
static struct class *gdio_class;

static int gdio_open(struct inode *inode, struct file *filp)
{
    struct gdio_chrdev *dev =
        (struct gdio_chrdev *)container_of(inode->i_cdev, struct gdio_chrdev,
                          dev);
    filp->private_data = dev;

    DRV_DBG("[gdio]: open\n");

    dev->va_gdio = ioremap(0xC20C3140, sizeof(GDIO_REG));

    return 0;
}

static int gdio_release(struct inode *inode, struct file *filp)
{
    struct gdio_chrdev *dev =
        (struct gdio_chrdev *)container_of(inode->i_cdev, struct gdio_chrdev,
                          dev);   

    iounmap(dev->va_gdio); 

    DRV_DBG("[gdio]: release\n");
    return 0;
}


static ssize_t gdio_read(struct file *filp, char __user * buf,
                size_t count, loff_t * ppos)
{
    struct gdio_chrdev *dev = (struct gdio_chrdev *)filp->private_data;

    char val;
    if (*ppos < 0x10)
    {
        val = (PGDIO->sync_dpv_chv_i & (1 << (*ppos & 0xf))) > 0 ? 1 : 0;
    }
    else
    {
        val = (PGDIO->di_bus & (1 << (*ppos & 0xf))) > 0 ? 1 : 0;
    }
	
    put_user(val, buf);
	
    return 1;
}

static ssize_t gdio_write(struct file *filp, const char __user * buf,
                size_t count, loff_t * ppos)
{
    struct gdio_chrdev *dev = (struct gdio_chrdev *)filp->private_data;

	char val, idx = *ppos & 0xf;
    get_user(val, buf);

    if (*ppos < 0x10)
    {
        if (val)	PGDIO->sync_dpv_chv_o |= (1 << idx);
	    else PGDIO->sync_dpv_chv_o &= ~(1 << idx);
    }
    else
    {
        DRV_DBG("set %d to %d\n", *ppos, val);
        if (val)	PGDIO->do_bus |= (1 << idx);
	    else PGDIO->do_bus &= ~(1 << idx);
    }

    
	return 1;
}



static struct file_operations gdio_fops = {
    .owner = THIS_MODULE,
    .open = gdio_open,
    .release = gdio_release,
    .read = gdio_read,
    .write = gdio_write,
    .llseek = noop_llseek
};

static struct gdio_chrdev gdio_cdev[DEV_CNT];

static __init int gdio_init(void)
{
    dev_t cur_dev;
    int i;

    DRV_DBG("[gdio]: chrdev init \n");


    alloc_chrdev_region(&devid, 0, DEV_CNT, DEV_NAME);

    gdio_class = class_create(THIS_MODULE, DEV_NAME);

    for (i = 0; i < DEV_CNT; i++) {
        cdev_init(&gdio_cdev[i].dev, &gdio_fops);
        gdio_cdev[i].dev.owner = THIS_MODULE;

        cur_dev = MKDEV(MAJOR(devid), MINOR(devid) + i);

        cdev_add(&gdio_cdev[i].dev, cur_dev, 1);

        device_create(gdio_class, NULL, cur_dev, NULL,
                  DEV_NAME "%d", i);
    }

    return 0;
}

static __exit void gdio_exit(void)
{
    int i;
    dev_t cur_dev;
    DRV_DBG("[gdio]: chrdrv exit\n");
    
    for (i = 0; i < DEV_CNT; i++) {
        cur_dev = MKDEV(MAJOR(devid), MINOR(devid) + i);

        device_destroy(gdio_class, cur_dev);

        cdev_del(&gdio_cdev[i].dev);
    }
    unregister_chrdev_region(devid, DEV_CNT);
    class_destroy(gdio_class);
}

module_init(gdio_init);
module_exit(gdio_exit);


MODULE_LICENSE("GPL");
MODULE_AUTHOR("RainbowSeeker");
MODULE_DESCRIPTION("Driver for gdio of fpga");
