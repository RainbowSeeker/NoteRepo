#include <linux/init.h>
#include <linux/module.h>
#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/io.h>
#include <linux/delay.h>
#define DEV_NAME            "engineio"
#define DEV_CNT           	(1)

// #define DRV_DBG(...)		pr_info(__VA_ARGS__)

#ifndef DRV_DBG
#define DRV_DBG(...)
#endif // DRV_DBG


typedef struct {
	uint32_t  io[55];
} EngineIO_REG;


struct engineio_chrdev {
    struct cdev dev;
    EngineIO_REG __iomem *va_io;      
};

static dev_t devid;
static struct class *engineio_class;

static int engineio_open(struct inode *inode, struct file *filp)
{
    struct engineio_chrdev *dev =
        (struct engineio_chrdev *)container_of(inode->i_cdev, struct engineio_chrdev,
                          dev);
    filp->private_data = dev;

    DRV_DBG("[engineio]: open\n");

    dev->va_io = ioremap(0xC3000000, sizeof(EngineIO_REG));

    return 0;
}

static int engineio_release(struct inode *inode, struct file *filp)
{
    struct engineio_chrdev *dev =
        (struct engineio_chrdev *)container_of(inode->i_cdev, struct engineio_chrdev,
                          dev);
   
    iounmap(dev->va_io); 

    DRV_DBG("[engineio]: release\n");
    return 0;
}

static ssize_t engineio_read(struct file *filp, char __user * buf,
                size_t count, loff_t * ppos)
{
    struct engineio_chrdev *dev = (struct engineio_chrdev *)filp->private_data;

    if (*ppos >= 55)
    {
        pr_warn("engineio_read wrong idx:%d", *ppos);
        return -1;
    }
    
	uint16_t val = dev->va_io->io[*ppos] & 0xFFFF;
    DRV_DBG("[engineio]: read pos:%d val:%d\n", *ppos, val);
	put_user(val, (uint16_t __user *)buf);
	
    return 1;
}

static ssize_t engineio_write(struct file *filp, const char __user * buf,
                size_t count, loff_t * ppos)
{
    struct engineio_chrdev *dev = (struct engineio_chrdev *)filp->private_data;

    if (*ppos >= 13)
    {
        pr_warn("engineio_write wrong idx:%d", *ppos);
        return -1;
    }
    
	uint16_t val;
    get_user(val, (uint16_t __user *)buf);
    DRV_DBG("[engineio]: write pos:%d val:0x%x\n", *ppos, val);
	dev->va_io->io[*ppos] = val;

	return 1;
}


static struct file_operations engineio_fops = {
    .owner = THIS_MODULE,
    .open = engineio_open,
    .release = engineio_release,
    .read = engineio_read,
    .write = engineio_write,
    .llseek = noop_llseek
};

static struct engineio_chrdev engineio_cdev[DEV_CNT];

static __init int engineio_init(void)
{
    dev_t cur_dev;
    int i;
    DRV_DBG("[engineio]: chrdev init \n");


    alloc_chrdev_region(&devid, 0, DEV_CNT, DEV_NAME);

    engineio_class = class_create(THIS_MODULE, DEV_NAME);

    for (i = 0; i < DEV_CNT; i++) {
        cdev_init(&engineio_cdev[i].dev, &engineio_fops);
        engineio_cdev[i].dev.owner = THIS_MODULE;

        cur_dev = MKDEV(MAJOR(devid), MINOR(devid) + i);

        cdev_add(&engineio_cdev[i].dev, cur_dev, 1);

        device_create(engineio_class, NULL, cur_dev, NULL,
                  DEV_NAME "%d", i);
    }

    return 0;
}

static __exit void engineio_exit(void)
{
    int i;
    dev_t cur_dev;
    DRV_DBG("[engineio]: chrdrv exit\n");
    
    for (i = 0; i < DEV_CNT; i++) {
        cur_dev = MKDEV(MAJOR(devid), MINOR(devid) + i);

        device_destroy(engineio_class, cur_dev);

        cdev_del(&engineio_cdev[i].dev);
    }
    unregister_chrdev_region(devid, DEV_CNT);
    class_destroy(engineio_class);
}

module_init(engineio_init);
module_exit(engineio_exit);


MODULE_LICENSE("GPL");
MODULE_AUTHOR("RainbowSeeker");
MODULE_DESCRIPTION("Driver for engineio of fpga");
