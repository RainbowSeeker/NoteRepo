#include <linux/init.h>
#include <linux/module.h>
#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/io.h>
#include <linux/delay.h>
#include <linux/ioctl.h>

#define DEV_NAME            "m1394b"
#define DEV_CNT           	(5)

// #define DRV_DBG(...)		pr_info(__VA_ARGS__)

#ifndef DRV_DBG
#define DRV_DBG(...)
#endif // DRV_DBG

#define  M1394_NODE_NUM		5

#define  CC_MODE			0x1
#define  RN_MODE			0x2

#define  M1394_TX_MSG_MAX	8	//不能修改
#define  M1394_RX_MSG_MAX	8	//不能修改

typedef struct 
{
	u8 mode : 2;
	u8 tx_msg_num;
	struct 
	{
		u32 tx_len;
		u32 tx_msg_id;
	}tx_msg[M1394_TX_MSG_MAX];
	
	u8 rx_msg_num;
	struct 
	{
		u32 rx_msg_id;
	}rx_msg[M1394_RX_MSG_MAX];
	
}m1394_conf_t;

/************************宏 定 义******************************/
#define  TX_RX_MAX_LEN		(256 * 4)		//unit:bytes

#define  TX_DBUF_LEN		0x4000		// can't be changed because of rx/tx buffer toggle independently
#define  DATA_BUF_MAX_LEN	0x8000

#define  NODE_CTRL_BASE		0x10000
#define  NODE_STOF_BASE		0x10204
#define  RX_INDEX_BASE		0x13000
#define  TX_INDEX_BASE		0x14000

#define pm1394_ctrl        		((PM1394_CTRL)(dev->va_node_base + NODE_CTRL_BASE))
#define pm1394_stof        		((PSTOF_CTRL)(dev->va_node_base + NODE_STOF_BASE))

/************************类型定义******************************/
typedef struct __M1394_CTRL__ {
	u32  bak_0;				// 0x00
	u32  intr_status;		// 0x04
	u32  intr_clr;			// 0x08
	u32  intr_mask;			// 0x0C
	u32  intr_mask_clr;		// 0x10
	u32  bak_14[6];			// 0x14
	u32  hb_cycle;			// 0x2C
	u32  tx_ctrl;			// 0x30
	u32  bak_34[17];			// 0x34
	u32  tx_frame_cnt;       // 0x78
	u32  bus_rst_cnt;		// 0x7C
	u32  tx_index_cnt;       // 0x80
	u32  rx_index_cnt;		// 0x84
	u32  stof_cnt;			// 0x88
	u32  tx_error_cnt;       // 0x8C
	u32  rx_error_cnt;       // 0x90
	u32  bak_94[3];			// 0x94
	u32  mode;				// 0xA0
	u32  start_work;			// 0xA4
	u32  stop_work;			// 0xA8
	u32  bak_ac[4];			// 0xAC
	u32  cc_ctrl;			// 0xBC
	u32  bak_c0;				// 0xC0
	u32  stof_cycle;			// 0xC4
	u32  bak_c8;				// 0xC8
	u32  channel_filter;		// 0xCC
	u32  bak_d0[4];			// 0xD0
	u32  rx_buf_begin;		// 0xE0
	u32  rx_buf_end;			// 0xE4
	u32  tx_data_update;		// 0xE8
	u32  bak_ec;				// 0xEC
	u32  tx_buf_begin;		// 0xF0
	u32  tx_buf_end;			// 0xF4
	u32  bak_F8[14];			// 0xF8	
	u32	message_id_en;		// 0x130
	u32	message_id[8];		// 0x134
	u32	bak_154;			// 0x154
	u32  rx_buf_lock;		// 0x158
	u32  rx_index_num;		// 0x15C
} M1394_CTRL, *PM1394_CTRL;

typedef struct _STOF_CTRL_ {
	u32  head;
	u32  bak_0;
} STOF_CTRL, *PSTOF_CTRL;

typedef struct _TX_INDEX_ {
	u32  ctrl_bak;
	u32  tx_offset;	// unit: us
	u32  chan_addr;
} TX_INDEX, *PTX_INDEX;

typedef struct _RX_INDEX_ {
	u32  status;
	u32  delay;
	u32  tfactor_addr;
	u32  time;
} RX_INDEX, *PRX_INDEX;

typedef struct 
{
	u32  flag;			//数据刷新标志
	u32 	len;			//数据长度
	u32  data[512];		//数据缓存
} RX_MSG_DATA;


struct m1394_chrdev {
    struct cdev 	dev;
    void __iomem 	*va_node_base;        
    u32 __iomem 	*va_en_ctrl;        
    u32 			tx_addr_offset[M1394_TX_MSG_MAX];        
    uint8_t     	portid;           
    uint8_t     	is_work;
	
	m1394_conf_t 	conf;           
};


static void cc_config(struct m1394_chrdev *dev, const m1394_conf_t *conf, u32 ctrl, u32 frame_cycle, u32 stof_head)
{
	u32 i;
	/*设置节点工作模式*/
	pm1394_ctrl->mode = CC_MODE;

	/*设置节点控制信息*/
	pm1394_ctrl->cc_ctrl = ctrl;

	/*设置帧周期*/
	pm1394_ctrl->stof_cycle = frame_cycle;

	/*设置接收的起点和终点偏移*/
	pm1394_ctrl->tx_buf_begin = 0;
	pm1394_ctrl->tx_buf_end = TX_DBUF_LEN - 4;

	/*设置发送的起点和终点偏移*/
	pm1394_ctrl->rx_buf_begin = TX_DBUF_LEN;
	pm1394_ctrl->rx_buf_end = DATA_BUF_MAX_LEN - 4;
	
	/*设置消息id过滤接收数据*/
	pm1394_ctrl->channel_filter = (1 << 31);
	
	pm1394_ctrl->message_id_en = (0xFF >> (M1394_RX_MSG_MAX - conf->rx_msg_num));
	for (i = 0; i < conf->rx_msg_num; i++)
	{
		pm1394_ctrl->message_id[i] = conf->rx_msg[i].rx_msg_id;
	}
	
	/*设置STOF包头*/
	pm1394_stof->head = stof_head;
	pm1394_stof->bak_0 = 0;
}

/*************************************************************
*FunctionName:	rn_config
*
*Description:
*				配置RN节点。
*Param:
*				node:节点号。
*Return:
*				无。
*Modify:
*
**************************************************************/
static void rn_config(struct m1394_chrdev *dev, const m1394_conf_t *conf)
{
	u32 i;
	/*设置节点工作模式*/
	pm1394_ctrl->mode = RN_MODE;
	
	/*设置消息id过滤接收数据*/
	pm1394_ctrl->channel_filter = (1 << 31);
	
	pm1394_ctrl->message_id_en = (0xFF >> (M1394_RX_MSG_MAX - conf->rx_msg_num));
	for (i = 0; i < conf->rx_msg_num; i++)
	{
		pm1394_ctrl->message_id[i] = conf->rx_msg[i].rx_msg_id;
	}
		
	/*设置接收的起点和终点偏移*/
	pm1394_ctrl->tx_buf_begin = 0;
	pm1394_ctrl->tx_buf_end = TX_DBUF_LEN - 4;

	/*设置发送的起点和终点偏移*/
	pm1394_ctrl->rx_buf_begin = TX_DBUF_LEN;
	pm1394_ctrl->rx_buf_end = DATA_BUF_MAX_LEN - 4;
}


#define node_start()        pm1394_ctrl->start_work = 0x7
#define node_stop()         pm1394_ctrl->stop_work = 0x7
#define tx_data_update()    pm1394_ctrl->tx_data_update = 1


/*************************************************************
*FunctionName:	config_tx_index
*
*Description:
*				配置发送节点信息。
*Param:
*				node:节点号。
*Return:
*				无。
*Modify:
*
**************************************************************/
static void config_tx_index(struct m1394_chrdev *dev, const m1394_conf_t *conf)
{
	PTX_INDEX     ptx_index0  = ((PTX_INDEX)(dev->va_node_base + TX_INDEX_BASE));
	PTX_INDEX     ptx_index;
	u32 preAddr;
	u32 i;

	/*配置所有消息的发送信息*/
	for(i = 0; i < conf->tx_msg_num; i++)
	{
		/*获取节点消息地址*/
		ptx_index = ptx_index0 + i;
		
		/*节点第一包数据偏移地址为0*/
		if(i == 0)
		{
			/*设置控制信息为非背靠背模式*/
			ptx_index->ctrl_bak = 0xC0170000;
			
			/*设置时间偏移*/
			ptx_index->tx_offset = 1800;

			/*设置偏移地址为0*/
			preAddr = 0;
		}
		else
		{
			/*设置控制信息为非背靠背模式*/
			ptx_index->ctrl_bak = 0xE0170000;

			/*设置时间偏移*/
			ptx_index->tx_offset = 1800 + 30*i;
		
			/*设置偏移地址*/
			preAddr += conf->tx_msg[i - 1].tx_len;
		}

		/*数据8字节对齐*/
		preAddr = (preAddr + 0x7 ) & 0xFFFFFFF8;
	
		/*计算节点消息对应的地址*/
		ptx_index->chan_addr = preAddr;
		dev->tx_addr_offset[i]		= pm1394_ctrl->tx_buf_begin + preAddr;

		u32 *ptx_msg = ((u32 *)(dev->va_node_base + dev->tx_addr_offset[i]));

		/*设置包头*/
		*(ptx_msg)  	= ((conf->tx_msg[i].tx_len-4)<<16) | 0xA0;

		/*设置消息ID*/
		*(ptx_msg + 1)  = conf->tx_msg[i].tx_msg_id;

		/*设置长度*/	
		*(ptx_msg + 4)  = conf->tx_msg[i].tx_len;
	}

	/*设置为当前节点最后一条消息*/
	ptx_index->ctrl_bak &= ~(1 << 31);
}

#define m1394_rx_buf_lock()     pm1394_ctrl->rx_buf_lock = 1
#define m1394_rx_buf_unlock()   pm1394_ctrl->rx_buf_lock = 0


static void m1394_start(struct m1394_chrdev *dev)
{
	const m1394_conf_t *conf = &dev->conf;
	
	//按照功能配置总线结点
	if (conf->mode == CC_MODE)
	{
		/*停止所有CC节点*/
		node_stop();

		/*配置所有CC节点*/
		cc_config(dev, conf, 5, 6715, 0x00281FA0);

		/*配置所有CC发送节点*/
		config_tx_index(dev, conf);

		/*更新所有CC发送数据*/
		tx_data_update();

		/*启动CC节点*/
		node_start();
	}
	else if (conf->mode == RN_MODE)
	{
		/*配置所有RN节点*/
		rn_config(dev, conf);

		/*配置所有RN发送节点*/
		config_tx_index(dev, conf);

		/*启动RN节点*/
		node_start();
	}
}

static void m1394_stop(struct m1394_chrdev *dev)
{
	node_stop();
	// power off
	*dev->va_en_ctrl &= ~(0x1 << dev->portid);
}


static dev_t devid;
static struct class *m1394_class;

static int m1394_open(struct inode *inode, struct file *filp)
{
    struct m1394_chrdev *dev =
        (struct m1394_chrdev *)container_of(inode->i_cdev, struct m1394_chrdev,
                          dev);
    filp->private_data = dev;

    DRV_DBG("[m1394]: open\n");

    dev->va_node_base = ioremap(0xC2000000 + 0x20000 * (dev->portid), 0x20000);
    dev->va_en_ctrl = ioremap(0xC20C312C, 4);
	memset(&dev->conf, 0, sizeof(m1394_conf_t));
	dev->is_work = 0;

    // power on
	*dev->va_en_ctrl |= (0x1 << dev->portid);
	DRV_DBG("[m1394]: en:0x%x\n", *dev->va_en_ctrl);
    return 0;
}

static int m1394_release(struct inode *inode, struct file *filp)
{
    struct m1394_chrdev *dev =
        (struct m1394_chrdev *)container_of(inode->i_cdev, struct m1394_chrdev,
                          dev);

	m1394_stop(dev);
    iounmap(dev->va_node_base);        
    iounmap(dev->va_en_ctrl); 

    DRV_DBG("[m1394]: release\n");
    return 0;
}

static ssize_t m1394_read(struct file *filp, char __user * buf,
                size_t count, loff_t * ppos)
{
    struct m1394_chrdev *dev = (struct m1394_chrdev *)filp->private_data;
	PRX_INDEX   prx_index = (PRX_INDEX)(dev->va_node_base + RX_INDEX_BASE);
	u32	idx = *ppos;

	if (!dev->is_work)
	{
		pr_warn("please config bus firstly!\n");
		return 0;
	}
	
	count = min(TX_RX_MAX_LEN, count);

	/*加锁,避免读数的过程中写入数据*/
	m1394_rx_buf_lock();

	/*新异步流包未存储或不存在索引号，直接返回错误*/
    if(!(pm1394_ctrl->intr_status & (1 << 23)) || idx >= (pm1394_ctrl->rx_index_num & 0xF))
	{
		m1394_rx_buf_unlock();
		DRV_DBG("[m1394]: No pkg\n");
		return 0;
	}
	
	/*获取消息长度*/
	count = min((prx_index + idx)->status & 0xFFFF - 4, count);
	// pm1394_ctrl->intr_clr |= (1 << 23);
	int val;
	int i;
	u32 *rx_msg = (u32 *)(dev->va_node_base + 0x4000 + 0x400 * idx);

	DRV_DBG("[m1394]: node:%d,idx:%d,id:0x%08x,len:%d", dev->portid, idx, rx_msg[1],count);
        
	for(i = 0; i < count / 4; i++)
	{
		val = *(rx_msg + 7 + i);
		put_user(val, (u32 __user *)((u32 __user *)buf + i));
	}

	/*开锁,允许写入新的数据*/
	m1394_rx_buf_unlock();

    return count;
}

static ssize_t m1394_write(struct file *filp, const char __user * buf,
                size_t count, loff_t * ppos)
{
    struct m1394_chrdev *dev = (struct m1394_chrdev *)filp->private_data;
	u32	idx = *ppos;
	m1394_conf_t *conf = &dev->conf;
	if (!dev->is_work)
	{
		pr_warn("please config bus firstly!\n");
		return 0;
	}

	count = min(min(TX_RX_MAX_LEN, count), conf->tx_msg[idx].tx_len);

    DRV_DBG("[m1394]: write %d\n", count);

	int i;
	u32 val;
	u32 *ptx_msg = ((u32 *)(dev->va_node_base + dev->tx_addr_offset[idx]));
	/*更新消息数据内容*/
    for(i = 0; i < count / 4; i++)
    {
		get_user(val, (u32 __user *)((u32 __user *)buf + i));
		
    	*(ptx_msg + 7 + i) = val;	
    }

	/*更新数据标识*/
    tx_data_update();

	return count;
}


#define M1394_COM_ON	_IO('m', 0x01) 
#define M1394_COM_OFF	_IO('m', 0x02) 
#define M1394_SET_CONF	_IOW('m', 0x03, m1394_conf_t) 
#define M1394_GET_CONF	_IOW('m', 0x04, m1394_conf_t) 

static long m1394_ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
{
	struct m1394_chrdev *dev = (struct m1394_chrdev *)filp->private_data;
	void __user *argp = (void __user *)arg;
	switch (cmd)
	{
	case M1394_COM_ON:
		dev->is_work = 1;
		m1394_start(dev);
		DRV_DBG("[m1394] start to work.\n");
		break;
	case M1394_COM_OFF:
		dev->is_work = 0;
		m1394_stop(dev);
		DRV_DBG("[m1394] stop to work.\n");
		break;
	case M1394_SET_CONF:
		if (copy_from_user(&dev->conf, argp, sizeof(m1394_conf_t)))
			return -EFAULT;
		DRV_DBG("[m1394] recv conf.\n");
		DRV_DBG("[m1394] node[%d]:mode:%d, tx_num:%d, rx_num:%d", 
						dev->portid, 
						dev->conf.mode, 
						dev->conf.tx_msg_num,
						dev->conf.rx_msg_num);
		break;
	case M1394_GET_CONF:
		if (copy_to_user(argp, &dev->conf, sizeof(m1394_conf_t)))
			return -EFAULT;
		DRV_DBG("[m1394] send conf.\n");
		break;
	default:
		break;
	}
	
	return 0;
}

static struct file_operations m1394_fops = {
    .owner = THIS_MODULE,
    .open = m1394_open,
    .release = m1394_release,
    .read = m1394_read,
    .write = m1394_write,
	.llseek = noop_llseek,
	.unlocked_ioctl = m1394_ioctl,
};

static struct m1394_chrdev m1394_cdev[DEV_CNT];

static __init int m1394_init(void)
{
    dev_t cur_dev;
	int i;
    DRV_DBG("[m1394]: chrdev init \n");


    alloc_chrdev_region(&devid, 0, DEV_CNT, DEV_NAME);

    m1394_class = class_create(THIS_MODULE, DEV_NAME);

    for (i = 0; i < DEV_CNT; i++) {
        cdev_init(&m1394_cdev[i].dev, &m1394_fops);
        m1394_cdev[i].dev.owner = THIS_MODULE;
        m1394_cdev[i].portid = i;

        cur_dev = MKDEV(MAJOR(devid), MINOR(devid) + i);

        cdev_add(&m1394_cdev[i].dev, cur_dev, 1);

        device_create(m1394_class, NULL, cur_dev, NULL,
                  DEV_NAME "%d", i);
    }

    return 0;
}

static __exit void m1394_exit(void)
{
    int i;
    dev_t cur_dev;
    DRV_DBG("[m1394]: chrdrv exit\n");
    
    for (i = 0; i < DEV_CNT; i++) {
        cur_dev = MKDEV(MAJOR(devid), MINOR(devid) + i);

        device_destroy(m1394_class, cur_dev);

        cdev_del(&m1394_cdev[i].dev);
    }
    unregister_chrdev_region(devid, DEV_CNT);
    class_destroy(m1394_class);
}

module_init(m1394_init);
module_exit(m1394_exit);


MODULE_LICENSE("GPL");
MODULE_AUTHOR("RainbowSeeker");
MODULE_DESCRIPTION("Driver for m1394 of fpga");
